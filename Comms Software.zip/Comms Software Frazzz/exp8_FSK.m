% Binary Frequency Shift Keying:
clear all;
close all;
clc;

bit_d = 1e-3; % bit duration in sec
f1 = 10000; % frequency of the high-frequency (HF) carrier in Hz
f2 = f1 / 2; % frequency of the low-frequency (LF) carrier in Hz
fs = 10 * f1; % Sampling rate

n = 0:1:(bit_d * fs) - 1; % Discrete time
carr1 = cos(2 * pi * (f1 / fs) * n); % HF Carrier wave for one bit duration
carr2 = cos(2 * pi * (f2 / fs) * n); % LF Carrier wave for one bit duration
digi_data = [1 0 0 1 1 0 1 0]; % digital data to be transmitted
carr = repmat(carr1, size(digi_data)); % Carrier for the entire duration of the data sequence
t = 0:1/fs:(length(carr) - 1) / fs; % time for the entire duration of the data sequence

% Encoding the data:
enc_data = [];
for i = 1:length(digi_data)
    if digi_data(i) == 1
        enc_data = [enc_data ones(1, length(n))];
    else
        enc_data = [enc_data zeros(1, length(n))];
    end
end

% Modulation:
s = [];
for i = 1:length(digi_data)
    if digi_data(i) == 1
        s = [s carr1]; % HF carrier for bit 1
    else
        s = [s carr2]; % LF carrier for bit 0
    end
end

% Plotting the data sequence:
figure(1);
subplot(3, 1, 1);
plot(t, enc_data, 'linewidth', 2);
xlabel('Time in sec');
ylabel('Amplitude');
title('Digital Data');

% Plotting the unmodulated carrier:
subplot(3, 1, 2);
plot(t, carr, 'linewidth', 2);
xlabel('Time in sec');
ylabel('Amplitude');
title('Unmodulated Carrier');

% Plotting the modulated carrier, FSK waveform:
subplot(3, 1, 3);
plot(t, s, 'linewidth', 2);
xlabel('Time in sec');
ylabel('Amplitude');
title('Modulated Carrier, FSK waveform');
