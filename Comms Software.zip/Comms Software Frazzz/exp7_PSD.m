clear all;
close all;
clc;

% Input Parameters
Rb = 1; % Bit rate in bits per second
Tb = 1 / Rb; % Bit duration
f = 0:0.01 * Rb:2 * Rb; % frequency from 0 to 2 times the bit rate
x = f * Tb;

% Power Spectral Density of Unipolar Signal
P1 = 0.25 * Tb * (sinc(x) .* sinc(x)) + 0.25 * dirac(f);

% Power Spectral Density of Polar Signal
P2 = Tb * (sinc(x) .* sinc(x));

% Power Spectral Density of Bipolar Signal
P3 = Tb * (sinc(x)).^2 .* (sin(pi * x)).^2;

% Power Spectral Density of Manchester Signal
P4 = Tb * (sinc(x / 2)).^2 .* (sin(pi * x / 2)).^2;

% Plotting Power Spectral Density of Binary line codes
figure(1);
plot(f, P1, 'r'), hold on;
plot(f, P2, 'g');
plot(f, P3, 'b');
plot(f, P4, 'm');
grid on;
box on;
xlabel('fTb ---->');
ylabel('Power Spectral Density ---->');
title('PSD for Various Binary Line Codes');
legend('PSD for Unipolar Signal', 'PSD for Polar Signal', ...
    'PSD for Bipolar Signal', 'PSD for Manchester Signal');
