clear all;
close all;
clc;

% Generate CT Signal:
fsct = 10000; % Step 1: Taking a large sampling rate to simulate CT signal

% Step 2: Signals in real life contain bands of frequencies
% f1 to f8 are 8 different frequency components in Hz
f1 = 2; f2 = 10; f3 = 25;
f4 = 50; f5 = 75; f6 = 100;
f7 = 200; f8 = 500;

% Step 3: Duration of the signal in seconds
t = 2;

% Step 4: Discrete time index (sample number)
n = 0:1:(t * fsct) - 1;

% Step 5: Generating different frequency sinusoids corresponding to f1 to f8
x1 = sin(2 * pi * (f1 / fsct) * n);
x2 = sin(2 * pi * (f2 / fsct) * n);
x3 = sin(2 * pi * (f3 / fsct) * n);
x4 = sin(2 * pi * (f4 / fsct) * n);
x5 = sin(2 * pi * (f5 / fsct) * n);
x6 = sin(2 * pi * (f6 / fsct) * n);
x7 = sin(2 * pi * (f7 / fsct) * n);
x8 = sin(2 * pi * (f8 / fsct) * n);

% Step 6: Combining the different frequencies to form a composite signal
xct = x1 + (0.8 * x2) + (0.75 * x3) + (0.7 * x4) ...
    + (0.65 * x5) + (0.6 * x6) + (0.55 * x7) + (0.5 * x8);

% Plotting the time domain signal
figure(1);
plot(n / fsct, xct);
xlabel('Time in sec');
ylabel('Amplitude');
title('CT signal');

% Step 7: Converting time domain signal to frequency domain
Nct = length(xct); % Number of points in FFT
Xct = fft(xct, Nct); % Taking Fast Fourier Transform (FFT)

% Frequency index kct
kct = 0:1:Nct - 1;

% Converting integer frequency index kct to frequency in Hz
fct = kct * fsct / Nct;

% Step 8: Plotting the frequency spectrum
figure(2);
plot(fct, abs(Xct) / Nct);
grid on;
xlabel('Frequency in Hz');
ylabel('Magnitude');
title('Magnitude vs freq plot');

figure(3);
plot(fct, angle(Xct));
xlabel('Frequency in Hz');
ylabel('Phase in rad');
title('Phase vs freq plot');
