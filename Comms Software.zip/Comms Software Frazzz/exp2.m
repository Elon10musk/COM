clear all;
close all;
clc;

% Generate CT Signal:
fsct = 10000; % Taking a large sampling rate to simulate CT signal

% Signals in real life contain bands of frequencies:
% f1 to f8 are 8 different frequency components in Hz
f1 = 2; f2 = 10; f3 = 25;
f4 = 50; f5 = 75; f6 = 100;
f7 = 200; f8 = 500;

% Duration of the signal in seconds
t = 2;

% Discrete time index (sample number)
n = 0:1:(t * fsct) - 1;

% Generating different frequency sinusoids corresponding to f1 to f8
x1 = sin(2 * pi * (f1 / fsct) * n);
x2 = sin(2 * pi * (f2 / fsct) * n);
x3 = sin(2 * pi * (f3 / fsct) * n);
x4 = sin(2 * pi * (f4 / fsct) * n);
x5 = sin(2 * pi * (f5 / fsct) * n);
x6 = sin(2 * pi * (f6 / fsct) * n);
x7 = sin(2 * pi * (f7 / fsct) * n);
x8 = sin(2 * pi * (f8 / fsct) * n);

% Combining the different frequencies to form a composite signal
xct = x1 + (0.8 * x2) + (0.75 * x3) + (0.7 * x4) ...
    + (0.65 * x5) + (0.6 * x6) + (0.55 * x7) + (0.5 * x8);

% Plotting the time domain signal
figure(1);
subplot(2, 1, 1);
plot(n / fsct, xct);
xlabel('Time');
ylabel('Amplitude');
title('CT signal');

% Converting time domain signal to frequency domain
Nct = length(xct); % Number of points in FFT
Xct = fft(xct, Nct); % Taking Fast Fourier Transform (FFT)

% Frequency index kct
kct = 0:1:Nct - 1;

% Converting integer frequency index kct to frequency in Hz
fct = kct * fsct / Nct;

% Plotting the frequency spectrum
subplot(2, 1, 2);
plot(fct, abs(Xct) / Nct);
grid on;
xlabel('Frequency in Hz');
ylabel('Magnitude');
title('Magnitude vs freq plot');

% Sampled signal-1 with fs >= 2*fmax
fs1 = 1050; % fs >= 2*fmax
n1 = 0:1:(t * fs1) - 1; % Discrete time index (sample number)

% Generating different frequency sinusoids corresponding to f1 to f8
x11 = sin(2 * pi * (f1 / fs1) * n1);
x12 = sin(2 * pi * (f2 / fs1) * n1);
x13 = sin(2 * pi * (f3 / fs1) * n1);
x14 = sin(2 * pi * (f4 / fs1) * n1);
x15 = sin(2 * pi * (f5 / fs1) * n1);
x16 = sin(2 * pi * (f6 / fs1) * n1);
x17 = sin(2 * pi * (f7 / fs1) * n1);
x18 = sin(2 * pi * (f8 / fs1) * n1);

% Combining the different frequencies to form a composite signal
xs1 = x11 + (0.8 * x12) + (0.75 * x13) + (0.7 * x14) ...
    + (0.65 * x15) + (0.6 * x16) + (0.55 * x17) + (0.5 * x18);

% Plotting the time domain signal
figure(2);
subplot(2, 1, 1);
plot(n1 / fs1, xs1);
xlabel('Time');
ylabel('Amplitude');
title('Sampled signal fs >= 2*fmax');

% Converting time domain signal to frequency domain
Ns1 = length(xs1); % Number of points in FFT
Xs1 = fft(xs1, Ns1); % Taking Fast Fourier Transform (FFT)

% Frequency index ks1
ks1 = 0:Ns1 - 1;

% Converting integer frequency index ks1 to frequency in Hz
f = ks1 * fs1 / Ns1;

% Plotting the frequency spectrum
subplot(2, 1, 2);
plot(f, abs(Xs1) / Ns1);
grid on;
xlabel('Frequency in Hz');
ylabel('Magnitude');
title('Magnitude vs freq plot fs >= 2*fmax');

% Sampled signal-2 with fs < 2*fmax
fs2 = 800; % fs < 2*fmax
n2 = 0:1:(t * fs2) - 1; % Discrete time index (sample number)

% Generating different frequency sinusoids corresponding to f1 to f8
x21 = sin(2 * pi * (f1 / fs2) * n2);
x22 = sin(2 * pi * (f2 / fs2) * n2);
x23 = sin(2 * pi * (f3 / fs2) * n2);
x24 = sin(2 * pi * (f4 / fs2) * n2);
x25 = sin(2 * pi * (f5 / fs2) * n2);
x26 = sin(2 * pi * (f6 / fs2) * n2);
x27 = sin(2 * pi * (f7 / fs2) * n2);
x28 = sin(2 * pi * (f8 / fs2) * n2);

% Combining the different frequencies to form a composite signal
xs2 = x21 + (0.8 * x22) + (0.75 * x23) + (0.7 * x24) ...
    + (0.65 * x25) + (0.6 * x26) + (0.55 * x27) + (0.5 * x28);

% Plotting the time domain signal
figure(3);
subplot(2, 1, 1);
plot(n2 / fs2, xs2);
xlabel('Time');
ylabel('Amplitude');
title('Sampled signal fs < 2*fmax');

% Converting time domain signal to frequency domain
Ns2 = length(xs2); % Number of points in FFT
Xs2 = fft(xs2, Ns2); % Taking Fast Fourier Transform (FFT)

% Frequency index ks2
ks2 = 0:Ns2 - 1;

% Converting integer frequency index ks2 to frequency in Hz
f = ks2 * fs2/Ns2;
% Plotting the frequency specrum:
subplot(2,1,2),plot(f,abs(Xs2)/Ns2);
xlabel('frequency in Hz');
ylabel('Magnitude');
title('Magnitude vs freq plot fs < 2*fmax');
