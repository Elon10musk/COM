clear all;
close all;
clc;

init_state = [1 0 0 1]; % Initial state of the shift register
M = length(init_state); % Number of shift register
N = (2^M) - 1; % Length of the PN sequence
out_seq = []; % Variable to hold the output
temp1 = init_state;

for i = 1:N
    out_seq = [out_seq, temp1(1)];
    temp2 = circshift(temp1, -1); % Shifting of data
    % Implementation of generator polynomial x^4 + x^3 + 1:
    temp2(end) = xor(temp1(1), temp1(2));
    temp1 = temp2;
end

disp('The PN sequence for the generator polynomial x^4 + x^3 + 1:');
disp(out_seq);

out_seq(out_seq == 0) = -1;

figure(1);
stem(out_seq, 'filled');
